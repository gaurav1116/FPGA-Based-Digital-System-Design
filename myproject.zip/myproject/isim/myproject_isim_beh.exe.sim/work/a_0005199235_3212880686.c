/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x2f00eba5 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/.Xilinx/myfolder/myproject/myproject.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_0005199235_3212880686_p_0(char *t0)
{
    char t3[16];
    char *t1;
    unsigned char t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 568U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 2196);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(49, ng0);
    t4 = (t0 + 960U);
    t5 = *((char **)t4);
    t4 = (t0 + 3796U);
    t6 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t3, t5, t4, 1);
    t7 = (t3 + 12U);
    t8 = *((unsigned int *)t7);
    t9 = (1U * t8);
    t10 = (26U != t9);
    if (t10 == 1)
        goto LAB5;

LAB6:    t11 = (t0 + 2256);
    t12 = (t11 + 32U);
    t13 = *((char **)t12);
    t14 = (t13 + 40U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 26U);
    xsi_driver_first_trans_fast(t11);
    goto LAB3;

LAB5:    xsi_size_not_matching(26U, t9, 0);
    goto LAB6;

}

static void work_a_0005199235_3212880686_p_1(char *t0)
{
    char t17[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned char t15;
    unsigned char t16;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;

LAB0:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 936U);
    t11 = (25 - 25);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t4 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, t14);
    if (t4 == 1)
        goto LAB7;

LAB8:    t3 = (unsigned char)0;

LAB9:    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    t1 = (t0 + 2204);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 3869);
    t6 = (t0 + 2292);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast(t6);
    goto LAB3;

LAB5:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 1052U);
    t6 = *((char **)t2);
    t2 = (t0 + 3812U);
    t7 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t17, t6, t2, 1);
    t8 = (t17 + 12U);
    t18 = *((unsigned int *)t8);
    t19 = (1U * t18);
    t20 = (4U != t19);
    if (t20 == 1)
        goto LAB10;

LAB11:    t9 = (t0 + 2292);
    t10 = (t9 + 32U);
    t21 = *((char **)t10);
    t22 = (t21 + 40U);
    t23 = *((char **)t22);
    memcpy(t23, t7, 4U);
    xsi_driver_first_trans_fast(t9);
    goto LAB3;

LAB7:    t2 = (t0 + 776U);
    t5 = *((char **)t2);
    t15 = *((unsigned char *)t5);
    t16 = (t15 == (unsigned char)3);
    t3 = t16;
    goto LAB9;

LAB10:    xsi_size_not_matching(4U, t19, 0);
    goto LAB11;

}

static void work_a_0005199235_3212880686_p_2(char *t0)
{
    char *t1;
    int t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    int t16;
    char *t17;
    int t19;
    char *t20;
    int t22;
    char *t23;
    int t25;
    char *t26;
    int t28;
    char *t29;
    int t31;
    char *t32;
    int t34;
    char *t35;
    int t37;
    char *t38;
    int t40;
    char *t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    int t55;
    char *t56;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;

LAB0:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 936U);
    t2 = (25 - 25);
    t3 = (t2 * -1);
    t4 = (1U * t3);
    t5 = (0 + t4);
    t6 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, t5);
    if (t6 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 2212);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(67, ng0);
    t7 = (t0 + 1052U);
    t8 = *((char **)t7);
    t7 = (t0 + 3873);
    t10 = xsi_mem_cmp(t7, t8, 4U);
    if (t10 == 1)
        goto LAB6;

LAB23:    t11 = (t0 + 3877);
    t13 = xsi_mem_cmp(t11, t8, 4U);
    if (t13 == 1)
        goto LAB7;

LAB24:    t14 = (t0 + 3881);
    t16 = xsi_mem_cmp(t14, t8, 4U);
    if (t16 == 1)
        goto LAB8;

LAB25:    t17 = (t0 + 3885);
    t19 = xsi_mem_cmp(t17, t8, 4U);
    if (t19 == 1)
        goto LAB9;

LAB26:    t20 = (t0 + 3889);
    t22 = xsi_mem_cmp(t20, t8, 4U);
    if (t22 == 1)
        goto LAB10;

LAB27:    t23 = (t0 + 3893);
    t25 = xsi_mem_cmp(t23, t8, 4U);
    if (t25 == 1)
        goto LAB11;

LAB28:    t26 = (t0 + 3897);
    t28 = xsi_mem_cmp(t26, t8, 4U);
    if (t28 == 1)
        goto LAB12;

LAB29:    t29 = (t0 + 3901);
    t31 = xsi_mem_cmp(t29, t8, 4U);
    if (t31 == 1)
        goto LAB13;

LAB30:    t32 = (t0 + 3905);
    t34 = xsi_mem_cmp(t32, t8, 4U);
    if (t34 == 1)
        goto LAB14;

LAB31:    t35 = (t0 + 3909);
    t37 = xsi_mem_cmp(t35, t8, 4U);
    if (t37 == 1)
        goto LAB15;

LAB32:    t38 = (t0 + 3913);
    t40 = xsi_mem_cmp(t38, t8, 4U);
    if (t40 == 1)
        goto LAB16;

LAB33:    t41 = (t0 + 3917);
    t43 = xsi_mem_cmp(t41, t8, 4U);
    if (t43 == 1)
        goto LAB17;

LAB34:    t44 = (t0 + 3921);
    t46 = xsi_mem_cmp(t44, t8, 4U);
    if (t46 == 1)
        goto LAB18;

LAB35:    t47 = (t0 + 3925);
    t49 = xsi_mem_cmp(t47, t8, 4U);
    if (t49 == 1)
        goto LAB19;

LAB36:    t50 = (t0 + 3929);
    t52 = xsi_mem_cmp(t50, t8, 4U);
    if (t52 == 1)
        goto LAB20;

LAB37:    t53 = (t0 + 3933);
    t55 = xsi_mem_cmp(t53, t8, 4U);
    if (t55 == 1)
        goto LAB21;

LAB38:
LAB22:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 4113);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);

LAB5:    goto LAB3;

LAB6:    xsi_set_current_line(68, ng0);
    t56 = (t0 + 3937);
    t58 = (t0 + 2328);
    t59 = (t58 + 32U);
    t60 = *((char **)t59);
    t61 = (t60 + 40U);
    t62 = *((char **)t61);
    memcpy(t62, t56, 11U);
    xsi_driver_first_trans_fast_port(t58);
    goto LAB5;

LAB7:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 3948);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB8:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 3959);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB9:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 3970);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB10:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 3981);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB11:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 3992);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB12:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 4003);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB13:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 4014);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB14:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 4025);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB15:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 4036);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB16:    xsi_set_current_line(78, ng0);
    t1 = (t0 + 4047);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB17:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 4058);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB18:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 4069);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB19:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 4080);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB20:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 4091);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB21:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 4102);
    t8 = (t0 + 2328);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t1, 11U);
    xsi_driver_first_trans_fast_port(t8);
    goto LAB5;

LAB39:;
}


extern void work_a_0005199235_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0005199235_3212880686_p_0,(void *)work_a_0005199235_3212880686_p_1,(void *)work_a_0005199235_3212880686_p_2};
	xsi_register_didat("work_a_0005199235_3212880686", "isim/myproject_isim_beh.exe.sim/work/a_0005199235_3212880686.didat");
	xsi_register_executes(pe);
}
